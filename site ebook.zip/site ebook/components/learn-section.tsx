import { CheckCircle2 } from "lucide-react"

const learningPoints = [
  "Cuidados diários essenciais para cada tipo de pele",
  "Identificar seu tipo de pele corretamente",
  "Produtos essenciais para começar (sem gastar uma fortuna)",
  "Rotina perfeita para manhã e noite",
  "Erros comuns que destroem sua pele",
]

export default function LearnSection() {
  return (
    <section className="py-20 px-6 bg-white">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-neutral-900 mb-4 text-balance">O que você vai aprender</h2>
          <p className="text-neutral-600 text-lg">
            Conteúdo completo e prático para transformar sua rotina de skincare
          </p>
        </div>

        <div className="space-y-4">
          {learningPoints.map((point, index) => (
            <div
              key={index}
              className="flex gap-4 items-start p-6 rounded-xl bg-rose-50 hover:bg-rose-100 transition-colors"
            >
              <CheckCircle2 className="w-6 h-6 text-rose-500 flex-shrink-0 mt-1" />
              <p className="text-neutral-700 text-lg font-medium">{point}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
