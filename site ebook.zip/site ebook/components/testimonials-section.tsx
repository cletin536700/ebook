import { Star } from "lucide-react"

const testimonials = [
  {
    name: "Julia Silva",
    role: "Acabou com acne em 30 dias",
    content:
      "Eu tinha acne severa e nada funcionava. Seguindo o método, em 30 dias minha pele transformou completamente. Minha autoestima voltou!",
    before: "/woman-acne-before.jpg",
    after: "/woman-clear-skin-after.jpg",
    rating: 5,
  },
  {
    name: "Carolina Santos",
    role: "Pele ressecada resolvida",
    content:
      "Minha pele era tão ressecada que descamava. Com este ebook aprendi a hidratação correta. Agora tenho a pele mais bonita que já tive!",
    before: "/woman-dry-skin-before.jpg",
    after: "/woman-hydrated-skin-after.jpg",
    rating: 5,
  },
  {
    name: "Ana Costa",
    role: "Manchas desapareceram",
    content:
      "Tinha manchas de acne e nada tirava. O protocolo de clareamento do ebook funcionou em 45 dias. Recomendo demais!",
    before: "/woman-spots-blemishes-before.jpg",
    after: "/woman-clear-skin-after.jpg",
    rating: 5,
  },
]

export default function TestimonialsSection() {
  return (
    <section className="py-20 px-6 bg-white">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-neutral-900 mb-4 text-balance">Depoimentos de Resultados Reais</h2>
          <p className="text-neutral-600 text-lg">Confira as transformações de quem já seguiu o método</p>
        </div>

        <div className="grid md:grid-cols-1 lg:grid-cols-1 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="p-8 rounded-xl bg-gradient-to-br from-rose-50 to-pink-50 border border-rose-100"
            >
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-rose-500 text-rose-500" />
                ))}
              </div>

              <p className="text-neutral-700 text-lg mb-6 italic">"{testimonial.content}"</p>

              <div className="flex items-center gap-6 mb-6">
                <div className="flex-1">
                  <p className="font-bold text-neutral-900">{testimonial.name}</p>
                  <p className="text-sm text-rose-600 font-medium">{testimonial.role}</p>
                </div>
              </div>

              <div className="flex gap-4 items-center">
                <div className="text-center">
                  <p className="text-xs text-neutral-600 mb-2 font-medium">Antes</p>
                  <img
                    src={testimonial.before || "/placeholder.svg"}
                    alt="Antes"
                    className="w-20 h-20 rounded-lg object-cover"
                  />
                </div>
                <div className="text-2xl text-rose-500">→</div>
                <div className="text-center">
                  <p className="text-xs text-neutral-600 mb-2 font-medium">Depois</p>
                  <img
                    src={testimonial.after || "/placeholder.svg"}
                    alt="Depois"
                    className="w-20 h-20 rounded-lg object-cover"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
