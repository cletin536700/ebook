import { Button } from "@/components/ui/button"
import { Check } from "lucide-react"

export default function OfferSection() {
  return (
    <section id="offer-section" className="py-20 px-6 bg-gradient-to-b from-white via-rose-50 to-white">
      <div className="max-w-2xl mx-auto text-center">
        <div className="p-12 rounded-2xl bg-gradient-to-br from-rose-500 to-pink-500 text-white mb-8">
          <p className="text-lg font-medium mb-4 opacity-90">Oferta Especial</p>
          <div className="flex justify-center items-center gap-4 mb-4">
            <div className="text-3xl font-bold opacity-75 line-through">R$ 24,99</div>
            <div className="text-5xl font-bold">R$ 17,99</div>
          </div>
          <p className="text-lg opacity-90 mb-2">Investimento único no seu melhor ativo</p>
          <p className="text-sm opacity-75">Acesso vitalício a todas as atualizações</p>
        </div>

        <div className="space-y-4 mb-8">
          <div className="flex gap-3 items-center justify-center">
            <Check className="w-5 h-5 text-rose-500" />
            <p className="text-neutral-700 font-medium">Acesso imediato ao conteúdo completo em PDF</p>
          </div>
          <div className="flex gap-3 items-center justify-center">
            <Check className="w-5 h-5 text-rose-500" />
            <p className="text-neutral-700 font-medium">Bônus e atualizações futuras inclusos</p>
          </div>
        </div>

        <Button
          size="lg"
          className="bg-rose-500 hover:bg-rose-600 text-white px-8 py-7 text-xl rounded-full w-full md:w-full font-bold mb-6"
        >
          Quero começar agora
        </Button>

        <p className="text-neutral-600 text-sm">Pagamento seguro. 100% confiável.</p>
      </div>
    </section>
  )
}
