const units = [
  {
    number: "01",
    title: "Fundamentos da Pele",
    description: "Entenda como sua pele funciona e quais são seus tipos",
    topics: ["Estrutura da pele", "Tipos de pele", "pH e hidratação"],
  },
  {
    number: "02",
    title: "Diagnóstico e Análise",
    description: "Identifique seus problemas específicos de pele",
    topics: ["Auto-diagnóstico", "Problemas comuns", "Fatores de risco"],
  },
  {
    number: "03",
    title: "Produtos Essenciais",
    description: "Quais produtos você realmente precisa (e quais evitar)",
    topics: ["Limpador ideal", "Hidratante certo", "Protetor solar"],
  },
  {
    number: "04",
    title: "Rotinas Completas",
    description: "Passo a passo para manhã e noite",
    topics: ["Rotina matinal", "Rotina noturna", "Dicas extras"],
  },
  {
    number: "05",
    title: "Tratamentos Específicos",
    description: "Soluções para acne, manchas e outros problemas",
    topics: ["Anti-acne", "Clareamento", "Cicatrizes"],
  },
  {
    number: "06",
    title: "Erros a Evitar",
    description: "Os hábitos que estão destruindo sua pele",
    topics: ["Hábitos prejudiciais", "Mitos de skincare", "Proteção extra"],
  },
]

export default function EbookContentSection() {
  return (
    <section className="py-20 px-6 bg-gradient-to-b from-rose-50 to-white">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-neutral-900 mb-4 text-balance">O que você vai aprender</h2>
          <p className="text-neutral-600 text-lg">6 seções completas com guias práticos e conteúdo detalhado</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {units.map((unit, index) => (
            <div
              key={index}
              className="p-6 rounded-xl bg-white border border-rose-100 hover:shadow-lg transition-shadow"
            >
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center w-12 h-12 rounded-full bg-rose-500 text-white font-bold">
                    {unit.number}
                  </div>
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-neutral-900 mb-1">{unit.title}</h3>
                  <p className="text-sm text-neutral-600 mb-4">{unit.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {unit.topics.map((topic, i) => (
                      <span key={i} className="text-xs bg-rose-100 text-rose-700 px-3 py-1 rounded-full">
                        {topic}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
