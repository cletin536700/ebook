import { Users } from "lucide-react"

const audiences = [
  "Mulheres iniciantes em skincare",
  "Homens que querem melhorar sua pele",
  "Pessoas com acne e espinhas",
  "Quem tem manchas ou cicatrizes",
  "Pele oleosa ou ressecada",
]

export default function TargetAudienceSection() {
  return (
    <section className="py-20 px-6 bg-gradient-to-b from-rose-50 to-white">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-neutral-900 mb-4 text-balance">Para quem é este ebook</h2>
          <p className="text-neutral-600 text-lg">
            Se você se identifica com qualquer um destes, este ebook é para você
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          {audiences.map((audience, index) => (
            <div key={index} className="flex gap-3 items-center p-4 bg-white rounded-lg border border-rose-100">
              <Users className="w-5 h-5 text-rose-500 flex-shrink-0" />
              <p className="text-neutral-700 font-medium">{audience}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
