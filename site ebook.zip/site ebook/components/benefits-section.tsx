import { Sparkles } from "lucide-react"

const benefits = [
  {
    title: "Melhora Visível da Pele",
    description: "Resultados reais que você vai notar nos espelhos",
  },
  {
    title: "Redução de Acne",
    description: "Método comprovado para controlar e eliminar espinhas",
  },
  {
    title: "Rotina Simples",
    description: "Fácil de seguir, sem complicações ou produtos caros",
  },
  {
    title: "Aumento de Autoestima",
    description: "Sinta-se mais confiante com sua pele transformada",
  },
]

export default function BenefitsSection() {
  return (
    <section className="py-20 px-6 bg-white">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-neutral-900 mb-4 text-balance">Benefícios do método SkinCare Pro</h2>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {benefits.map((benefit, index) => (
            <div
              key={index}
              className="p-8 rounded-xl bg-gradient-to-br from-rose-50 to-pink-50 border border-rose-100"
            >
              <Sparkles className="w-8 h-8 text-rose-500 mb-4" />
              <h3 className="text-xl font-bold text-neutral-900 mb-2">{benefit.title}</h3>
              <p className="text-neutral-600">{benefit.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
