"use client"

import { Button } from "@/components/ui/button"

export default function HeroSection() {
  const handleScrollToOffer = () => {
    const offerSection = document.getElementById("offer-section")
    if (offerSection) {
      offerSection.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <section className="relative min-h-screen flex items-center justify-center bg-gradient-to-b from-white via-rose-50 to-white px-6 py-20">
      <div className="max-w-3xl text-center space-y-8">
        <div className="space-y-4">
          <h1 className="text-5xl md:text-6xl font-bold text-neutral-900 leading-tight text-pretty">
            Transforme sua pele em 7 dias com o método SkinCare Pro
          </h1>
          <p className="text-lg md:text-xl text-neutral-600 text-pretty">
            Aprenda os segredos reais para uma pele limpa, hidratada e bonita sem gastar muito.
          </p>
        </div>

        <Button
          size="lg"
          onClick={handleScrollToOffer}
          className="bg-rose-500 hover:bg-rose-600 text-white px-8 py-6 text-lg rounded-full w-full md:w-auto"
        >
          Quero acessar o ebook agora
        </Button>

        <div className="pt-12">
          <img
            src="/skincare-beauty-products-wellness.jpg"
            alt="Skincare beauty products"
            className="w-full max-w-md mx-auto rounded-2xl shadow-lg"
          />
        </div>
      </div>
    </section>
  )
}
