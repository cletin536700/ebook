import { Mail, MapPin } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-neutral-900 text-neutral-200 py-12 px-6">
      <div className="max-w-4xl mx-auto">
        <div className="grid md:grid-cols-3 gap-8 mb-8 pb-8 border-b border-neutral-800">
          <div>
            <h3 className="font-bold text-white mb-4">SkinCare Pro</h3>
            <p className="text-sm text-neutral-400">Transformando pele e autoestima com educação de qualidade.</p>
          </div>

          <div>
            <h4 className="font-bold text-white mb-4">Contato</h4>
            <div className="space-y-2 text-sm text-neutral-400">
              <div className="flex gap-2 items-center">
                <Mail className="w-4 h-4" />
                <a href="mailto:suporte@skincarepro.com" className="hover:text-rose-400 transition">
                  suporte@skincarepro.com
                </a>
              </div>
              <div className="flex gap-2 items-center">
                <MapPin className="w-4 h-4" />
                <p>Brasil</p>
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-bold text-white mb-4">Legal</h4>
            <div className="space-y-2 text-sm text-neutral-400">
              <a href="#" className="hover:text-rose-400 transition block">
                Termos de Serviço
              </a>
              <a href="#" className="hover:text-rose-400 transition block">
                Política de Privacidade
              </a>
              <a href="#" className="hover:text-rose-400 transition block">
                Política de Reembolso
              </a>
            </div>
          </div>
        </div>

        <div className="text-center text-sm text-neutral-500">
          <p>© 2025 SkinCare Pro. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  )
}
