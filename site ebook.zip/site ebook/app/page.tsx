import HeroSection from "@/components/hero-section"
import LearnSection from "@/components/learn-section"
import TargetAudienceSection from "@/components/target-audience-section"
import BenefitsSection from "@/components/benefits-section"
import EbookContentSection from "@/components/ebook-content-section"
import TestimonialsSection from "@/components/testimonials-section"
import OfferSection from "@/components/offer-section"
import Footer from "@/components/footer"

export const metadata = {
  title: "SkinCare Pro - Transforme sua pele em 7 dias",
  description:
    "Aprenda os segredos reais para uma pele limpa, hidratada e bonita sem gastar muito. Ebook completo com guia prático passo a passo.",
}

export default function Home() {
  return (
    <main className="w-full overflow-hidden">
      <HeroSection />
      <LearnSection />
      <TargetAudienceSection />
      <BenefitsSection />
      <EbookContentSection />
      <TestimonialsSection />
      <OfferSection />
      <Footer />
    </main>
  )
}
